﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Aeklys
{
    public partial class Form1 : Form
    {

        String PlayerName;




        public Form1()
        {
            InitializeComponent();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

            try
            {
                Directory.CreateDirectory(@"c:/Aeklys");
            }
            catch (Exception ea)
            {
                Console.WriteLine("The process failed: {0}", ea.ToString());
            }


            if (!File.Exists(@"C:\Aeklys\Database.txt"))
            {
                firstlogin.Show();
                // Create a file to write to.
                
            }
            if (File.Exists(@"C:\Aeklys\Database.txt"))
            {
                firstlogin.Hide();
                SqlLoginFayz();
                MonsterFayz();
                SkillFayz();
                BuffFayz();
            }
            PlayerValueList.Items.Add("lv");
            PlayerValueList.Items.Add("jp");
            PlayerValueList.Items.Add("tp");
            PlayerValueList.Items.Add("hp");
            PlayerValueList.Items.Add("mp");
            PlayerValueList.Items.Add("pk_count");
            PlayerValueList.Items.Add("dk_count");
            PlayerValueList.Items.Add("sex");
            PlayerValueList.Items.Add("race");
            PlayerValueList.Items.Add("permission");


            CreatureListValue.Items.Add("lv");
            CreatureListValue.Items.Add("jp");
            CreatureListValue.Items.Add("hp");
            CreatureListValue.Items.Add("mp");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run insert_gold(" + GOLD.Text + "," + PlayerName + ")");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run set_huntaholic_point(gv('huntaholic_point') + " + Hunta.Text + "," + PlayerName + ")");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run sv('" + PlayerValueList.Text + "'," + PlayerValue.Text + ","  + PlayerName + ")");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run scv(get_creature_handle(" + SlotCreature.Text + "),'" + CreatureListValue.Text + "'," + CreatureValue.Text + "," + PlayerName + ")");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run learn_all_skill()");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run learn_creature_all_skill()");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run open_storage()");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_auction_window()");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_donation_prop()");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_guild_create()");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_alliance_create()");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run creature_name_change_box(get_creature_handle(0)");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_huntaholic_lobby_window()");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_dungeon_stone(dungeon_id)");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_soulstone_craft_window()");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_soulstone_repair_window()");
        }

        private void SetFlagBt_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run set_flag('" + FlagName.Text + "','" + FlagValue.Text + "')");
        }

        private void flagdelete_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run del_flag('" + FlagName.Text + "')");
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("Unable to use this function : Code 10");
        }

        private void GuildCDButton_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run set_guild_block_time(" + GuildCD.Text + ", " + PlayerName + ")");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run recall_player(" + PlayerName  + ")");
        }

        private void button20_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run warp_to_revive_position(" + PlayerName + ")");
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run saveall()");
        }

        private void button22_Click(object sender, EventArgs e)
        {
            listView1.Items.Add(ListNamed.Text);

        }

        private void button23_Click(object sender, EventArgs e)
        {
            listView1.Items.Remove(listView1.SelectedItems[0]);
        }


        //Monster
        public void MonsterFayz()
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

          
            string select = "SELECT id,value FROM dbo.MonsterResource,StringResource_EN WHERE name_id = code";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView3.ReadOnly = true;
            dataGridView3.DataSource = ds.Tables[0];
          

        }
        //Monster


        //SkillFayz
        public void SkillFayz()
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";


            string select = "SELECT id,value FROM dbo.SkillResource,StringResource_EN WHERE text_id = code";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView5.ReadOnly = true;
            dataGridView5.DataSource = ds.Tables[0];


        }
        //SkillFayz

        public void SqlLoginFayz()
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();

            String connectionString = IP + ";" +  Arcadia + ";" + User + ";" + Pass + "";

            // ITEM
            string select = "SELECT id,value FROM dbo.ItemResource,StringResource_EN WHERE name_id = code";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = ds.Tables[0];
            // ITEM

        }


        /// BUFF
        public void BuffFayz()
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            
            string select = "SELECT state_id,value FROM dbo.StateResource,StringResource_EN WHERE text_id = code";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView2.ReadOnly = true;
            dataGridView2.DataSource = ds.Tables[0];
           

        }
        /// BUFF


        /// ITEM
        public void search(String ItemName)
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            var select = "SELECT ir.id, sr.[value] FROM dbo.ItemResource AS ir JOIN dbo.StringResource_EN AS sr ON ir.name_id = sr.code WHERE sr.[value] LIKE '%" + ItemName + "%'";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = ds.Tables[0];
        }
        /// ITEM

        public void searchMonster(String ItemName)
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            var select = "SELECT ir.id, sr.[value] FROM dbo.MonsterResource AS ir JOIN dbo.StringResource_EN AS sr ON ir.name_id = sr.code WHERE sr.[value] LIKE '%" + ItemName + "%'";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView3.ReadOnly = true;
            dataGridView3.DataSource = ds.Tables[0];
        }

        public void searchSkill(String ItemName)
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            var select = "SELECT ir.id, sr.[value] FROM dbo.SkillResource AS ir JOIN dbo.StringResource_EN AS sr ON ir.text_id = sr.code WHERE sr.[value] LIKE '%" + ItemName + "%'";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView5.ReadOnly = true;
            dataGridView5.DataSource = ds.Tables[0];
        }

        /// State Search 
        public void searchBuff(String ItemName)
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            var select = "SELECT ir.state_id, sr.[value] FROM dbo.StateResource AS ir JOIN dbo.StringResource_EN AS sr ON ir.text_id = sr.code WHERE sr.[value] LIKE '%" + ItemName + "%'";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView2.ReadOnly = true;
            dataGridView2.DataSource = ds.Tables[0];
        }
        /// State Search



        private void GiveItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run insert_item(" + Iditem.Text + "," + ItemAmmount.Text+ "," +  ItemEnchant.Text + "," + ItemLevel.Text + ")");
        }
                
        private void button24_Click(object sender, EventArgs e)
        {
            search(searchengine.Text);
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            Iditem.Text = row.Cells[0].Value.ToString();
            Nameitem5.Text = row.Cells[1].Value.ToString();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            searchBuff(SearchM.Text);
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow rows = dataGridView2.Rows[e.RowIndex];
            IDBUFF.Text = rows.Cells[0].Value.ToString();
            BuffName.Text = rows.Cells[1].Value.ToString();
        }

        private void SearchMonsters_Click(object sender, EventArgs e)
        {
            searchMonster(SearchMEngine.Text);
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow rowsa = dataGridView3.Rows[e.RowIndex];
            IdMonster.Text = rowsa.Cells[0].Value.ToString();
            NameMonster.Text = rowsa.Cells[1].Value.ToString();
        }

        private void dataGridView5_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow rowsz = dataGridView5.Rows[e.RowIndex];
            SkillID.Text = rowsz.Cells[0].Value.ToString();
            SkillName.Text = rowsz.Cells[1].Value.ToString();
        }

        private void SkillSearch_Click(object sender, EventArgs e)
        {
            searchSkill(SkillSearchEngine.Text);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            int valuebase = Convert.ToInt32(this.BuffTime.Text);
            int BuffTimed = valuebase * 100;
                PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run add_state(" + IDBUFF.Text + "," + BuffLevel.Text + "," + BuffTimed + "," + PlayerName + ")");
            
        }

        private void GiveMonster_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("//regenerate " + IdMonster.Text + " " + nbMonster.Text + "");
        }

        private void SkillGive_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run learn_skill( " + SkillID.Text +")");
        }

        private void button27_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run learn_creature_skill( " + SkillID.Text + ")");
        }

        private void logbutton_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = File.CreateText(@"C:\Aeklys\Database.txt"))
            {

                sw.WriteLine("Server = " + IpBox.Text + "");

                sw.WriteLine("Database = " + ArcadiaBox.Text + "");

                sw.WriteLine("User Id = "+ UserBox.Text + "");

                sw.WriteLine("Password = " + textBox4.Text + "");


            }

            firstlogin.Hide();
            SqlLoginFayz();
            MonsterFayz();
            SkillFayz();
            BuffFayz();
        }

        private void button28_Click(object sender, EventArgs e)
        {
            firstlogin.Show();
        }
    }
}
