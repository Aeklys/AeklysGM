﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Sockets;

namespace Aeklys
{
    public partial class Form1 : Form
    {

        String PlayerName;




        public Form1()
        {
            InitializeComponent();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

            try
            {
                Directory.CreateDirectory(@"c:/Aeklys");
            }
            catch (Exception ea)
            {
                Console.WriteLine("The process failed: {0}", ea.ToString());
            }


            if (!File.Exists(@"C:\Aeklys\Database.txt"))
            {
                firstlogin.Show();
                // Create a file to write to.
                
            }
            if (File.Exists(@"C:\Aeklys\Database.txt"))
            {
                firstlogin.Hide();
                SqlLoginFayz();
                MonsterFayz();
                SkillFayz();
                CreatureFayz();
                testfayz();
                BuffFayz();
            }
            PlayerValueList.Items.Add("lv");
            PlayerValueList.Items.Add("jp");
            PlayerValueList.Items.Add("tp");
            PlayerValueList.Items.Add("hp");
            PlayerValueList.Items.Add("mp");
            PlayerValueList.Items.Add("pk_count");
            PlayerValueList.Items.Add("dk_count");
            PlayerValueList.Items.Add("sex");
            PlayerValueList.Items.Add("race");
            PlayerValueList.Items.Add("permission");


            CreatureListValue.Items.Add("lv");
            CreatureListValue.Items.Add("jp");
            CreatureListValue.Items.Add("hp");
            CreatureListValue.Items.Add("mp");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run insert_gold(" + GOLD.Text + "," + PlayerName + ")");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run set_huntaholic_point(gv('huntaholic_point') + " + Hunta.Text + "," + PlayerName + ")");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run sv('" + PlayerValueList.Text + "'," + PlayerValue.Text + ","  + PlayerName + ")");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run scv(get_creature_handle(" + SlotCreature.Text + "),'" + CreatureListValue.Text + "'," + CreatureValue.Text + "," + PlayerName + ")");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run learn_all_skill()");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run learn_creature_all_skill()");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run open_storage()");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_auction_window()");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_donation_prop()");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_guild_create()");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_alliance_create()");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run creature_name_change_box(get_creature_handle(0)");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_huntaholic_lobby_window()");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_dungeon_stone(dungeon_id)");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_soulstone_craft_window()");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run show_soulstone_repair_window()");
        }

        private void SetFlagBt_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run set_flag('" + FlagName.Text + "','" + FlagValue.Text + "')");
        }

        private void flagdelete_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run del_flag('" + FlagName.Text + "')");
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run kick('" + kickplayer.Text + "')");
        }

        private void GuildCDButton_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run set_guild_block_time(" + GuildCD.Text + ", " + PlayerName + ")");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run recall_player(" + PlayerName  + ")");
        }

        private void button20_Click(object sender, EventArgs e)
        {
            PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run warp_to_revive_position(" + PlayerName + ")");
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run saveall()");
        }

        private void button22_Click(object sender, EventArgs e)
        {
            listView1.Items.Add(ListNamed.Text);

        }

        private void button23_Click(object sender, EventArgs e)
        {
            listView1.Items.Remove(listView1.SelectedItems[0]);
        }


        //Monster
        public void MonsterFayz()
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

          
            string select = "SELECT id,value FROM dbo.MonsterResource,"+ StringResource+" WHERE name_id = code";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView3.ReadOnly = true;
            dataGridView3.DataSource = ds.Tables[0];
          

        }
        //Monster


        //SkillFayz
        public void SkillFayz()
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";


            string select = "SELECT id,value FROM dbo.SkillResource," + StringResource + " WHERE text_id = code";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView5.ReadOnly = true;
            dataGridView5.DataSource = ds.Tables[0];


        }
        //SkillFayz


        public void CreatureFayz()
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";


            string select = "SELECT id,value FROM dbo.SummonResource," + StringResource + " WHERE name_id = code";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView6.ReadOnly = true;
            dataGridView6.DataSource = ds.Tables[0];


        }


        public void SqlLoginFayz()
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();

            String connectionString = IP + ";" +  Arcadia + ";" + User + ";" + Pass + "";

            // ITEM
            string select = "SELECT id,value FROM dbo.ItemResource,"+ StringResource + " WHERE name_id = code";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = ds.Tables[0];
            // ITEM

        }


        /// BUFF
        public void BuffFayz()
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            
            string select = "SELECT state_id,value FROM dbo.StateResource,"+StringResource+" WHERE text_id = code";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView2.ReadOnly = true;
            dataGridView2.DataSource = ds.Tables[0];
           

        }
        /// BUFF


        /// ITEM
        public void search(String ItemName)
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            var select = "SELECT ir.id, sr.[value] FROM dbo.ItemResource AS ir JOIN dbo." + StringResource + " AS sr ON ir.name_id = sr.code WHERE sr.[value] LIKE '%" + ItemName + "%'";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = ds.Tables[0];
        }
        /// ITEM

        public void searchMonster(String ItemName)
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();
            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            var select = "SELECT ir.id, sr.[value] FROM dbo.MonsterResource AS ir JOIN dbo."+ StringResource +" AS sr ON ir.name_id = sr.code WHERE sr.[value] LIKE '%" + ItemName + "%'";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView3.ReadOnly = true;
            dataGridView3.DataSource = ds.Tables[0];
        }

        public void searchSkill(String ItemName)
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            var select = "SELECT ir.id, sr.[value] FROM dbo.SkillResource AS ir JOIN dbo." + StringResource + " AS sr ON ir.text_id = sr.code WHERE sr.[value] LIKE '%" + ItemName + "%'";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView5.ReadOnly = true;
            dataGridView5.DataSource = ds.Tables[0];
        }

        /// State Search 
        public void searchBuff(String ItemName)
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            var select = "SELECT ir.state_id, sr.[value] FROM dbo.StateResource AS ir JOIN dbo."+ StringResource+" AS sr ON ir.text_id = sr.code WHERE sr.[value] LIKE '%" + ItemName + "%'";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView2.ReadOnly = true;
            dataGridView2.DataSource = ds.Tables[0];
        }
        /// State Search


        public void searchpets(String ItemName)
        {

            String filename = @"C:/Aeklys/Database.txt";
            string IP = File.ReadLines(filename).Skip(0).Take(1).First();
            string Arcadia = File.ReadLines(filename).Skip(1).Take(1).First();
            string User = File.ReadLines(filename).Skip(2).Take(1).First();
            string Pass = File.ReadLines(filename).Skip(3).Take(1).First();
            string StringResource = File.ReadLines(filename).Skip(4).Take(1).First();

            String connectionString = IP + ";" + Arcadia + ";" + User + ";" + Pass + "";

            var select = "SELECT ir.id, sr.[value] FROM dbo.SummonResource AS ir JOIN dbo." + StringResource + " AS sr ON ir.name_id = sr.code WHERE sr.[value] LIKE '%" + ItemName + "%'";
            var c = new SqlConnection(connectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView6.ReadOnly = true;
            dataGridView6.DataSource = ds.Tables[0];
        }


        private void GiveItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run insert_item(" + Iditem.Text + "," + ItemAmmount.Text+ "," +  ItemEnchant.Text + "," + ItemLevel.Text + ")");
        }
                
        private void button24_Click(object sender, EventArgs e)
        {
            search(searchengine.Text);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            Iditem.Text = row.Cells[0].Value.ToString();
            Nameitem5.Text = row.Cells[1].Value.ToString();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            searchBuff(SearchM.Text);
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow rows = dataGridView2.Rows[e.RowIndex];
            IDBUFF.Text = rows.Cells[0].Value.ToString();
            BuffName.Text = rows.Cells[1].Value.ToString();
        }

        private void SearchMonsters_Click(object sender, EventArgs e)
        {
            searchMonster(SearchMEngine.Text);
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow rowsa = dataGridView3.Rows[e.RowIndex];
            IdMonster.Text = rowsa.Cells[0].Value.ToString();
            NameMonster.Text = rowsa.Cells[1].Value.ToString();
        }

        private void dataGridView5_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow rowsz = dataGridView5.Rows[e.RowIndex];
            SkillID.Text = rowsz.Cells[0].Value.ToString();
            SkillName.Text = rowsz.Cells[1].Value.ToString();
        }

        private void SkillSearch_Click(object sender, EventArgs e)
        {
            searchSkill(SkillSearchEngine.Text);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            int valuebase = Convert.ToInt32(this.BuffTime.Text);
            int BuffTimed = valuebase * 100;
                PlayerName = "'" + listView1.SelectedItems[0].Text + "'";
            Clipboard.SetText("/run add_state(" + IDBUFF.Text + "," + BuffLevel.Text + "," + BuffTimed + "," + PlayerName + ")");
            
        }

        private void GiveMonster_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("//regenerate " + IdMonster.Text + " " + nbMonster.Text + "");
        }

        private void SkillGive_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run learn_skill(" + SkillID.Text +")");
        }

        private void button27_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run learn_creature_skill(" + SkillID.Text + ")");
        }

        private void logbutton_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = File.CreateText(@"C:\Aeklys\Database.txt"))
            {

                sw.WriteLine("Server = " + IpBox.Text + "");

                sw.WriteLine("Database = " + ArcadiaBox.Text + "");

                sw.WriteLine("User Id = "+ UserBox.Text + "");

                sw.WriteLine("Password = " + textBox4.Text + "");
                sw.WriteLine(stringres.Text);


            } 

            firstlogin.Hide();
            SqlLoginFayz();
            MonsterFayz();
            SkillFayz();
            BuffFayz();
            CreatureFayz();
        }

        private void button28_Click(object sender, EventArgs e)
        {
            firstlogin.Show();
        }

        

        private void searchpet_Click(object sender, EventArgs e)
        {
            searchpets(searchvaluepet.Text);
        }

        private void button29_Click(object sender, EventArgs e)
        {
                 Clipboard.SetText("/run insert_summon_by_summon_id(" + AddPet.Text + ")");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            String Job_Name = JobBox.Text;
            int id = 0;

            if (Job_Name == "Rogue")
            {
                id = 100;
            }

            if (Job_Name == "Fighter")
            {
                id = 101;
            }

            if (Job_Name == "Kahuna")
            {
                id = 102;
            }

            if (Job_Name == "Spell Singer")
            {
                id = 103;
            }

            if (Job_Name == "Champion")
            {
                id = 110;
            }

            if (Job_Name == "Archer")
            {
                id = 111;
            }

            if (Job_Name == "Druid")
            {
                id = 112;
            }

            if (Job_Name == "Battle Kahuna")
            {
                id = 113;
            }

            if (Job_Name == "Evoker")
            {
                id = 114;
            }

            if (Job_Name == "Berserker")
            {
                id = 120;
            }

            if (Job_Name == "Marksman")
            {
                id = 121;
            }

            if (Job_Name == "Magus")
            {
                id = 122;
            }

            if (Job_Name == "War Kahuna")
            {
                id = 123;
            }

            if (Job_Name == "Beast Master")
            {
                id = 124;
            }


            if (Job_Name == "Guide")
            {
                id = 200;
            }

            if (Job_Name == "Holy Warrior")
            {
                id = 201;
            }

            if (Job_Name == "Cleric")
            {
                id = 202;
            }

            if (Job_Name == "Breeder")
            {
                id = 203;
            }

            if (Job_Name == "Knight")
            {
                id = 210;
            }

            if (Job_Name == "Soldier")
            {
                id = 211;
            }

            if (Job_Name == "Bishop")
            {
                id = 212;
            }

            if (Job_Name == "Priest")
            {
                id = 213;
            }

            if (Job_Name == "Soul Breeder")
            {
                id = 214;
            }


            if (Job_Name == "Templar")
            {
                id = 220;
            }


            if (Job_Name == "Mercenary")
            {
                id = 221;
            }


            if (Job_Name == "Cardinal")
            {
                id = 222;
            }

            if (Job_Name == "Oracle")
            {
                id = 223;
            }

            if (Job_Name == "Master Breeder")
            {
                id = 224;
            }

            if (Job_Name == "Stepper")
            {
                id = 300;
            }

            if (Job_Name == "Strider")
            {
                id = 301;
            }

            if (Job_Name == "Dark Magician")
            {
                id = 302;
            }

            if (Job_Name == "Sorcerer")
            {
                id = 303;
            }

            if (Job_Name == "Assassin")
            {
                id = 310;
            }

            if (Job_Name == "Shadow Hunter")
            {
                id = 311;
            }

            if (Job_Name == "Chaos Magician")
            {
                id = 312;
            }

            if (Job_Name == "Warlock")
            {
                id = 313;
            }

            if (Job_Name == "Battle Summoner")
            {
                id = 314;
            }

            if (Job_Name == "Slayer")
            {
                id = 320;
            }

            if (Job_Name == "Deadeye")
            {
                id = 321;
            }

            if (Job_Name == "Void Mage")
            {
                id = 322;
            }

            if (Job_Name == "Corruptor")
            {
                id = 323;
            }

            if (Job_Name == "Overlord")
            {
                id = 324;
            }


            Clipboard.SetText("/run Run_JobChange_common('" + Job_Name + "'," + id + ")");


        }

        private void button30_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run announce('" + textBox6.Text + "')");
        }

        private void button31_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run kill_target()");
        }

        private void stade_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run creature_enhance(" + PetStadeSlot.Text + "," + PetStade.Text +")");
        }

        private void testfayz()
        {
            this.dataGridView4.Rows.Insert(0, "Horizon", "152465", "76951");
            this.dataGridView4.Rows.Insert(1, "Katan", "117974", "59119");
            this.dataGridView4.Rows.Insert(2, "Laksy", "7363", "7101");
            this.dataGridView4.Rows.Insert(3, "Rondo", "138174", "105965");

            this.dataGridView4.Rows.Insert(4, "City of Ruins", "154666", "150287");
            this.dataGridView4.Rows.Insert(5, "Temple of Ancient", "201400", "151566");
            this.dataGridView4.Rows.Insert(6, "Temple of lost souls", "201400", "167649");
            this.dataGridView4.Rows.Insert(7, "City of Ruins", "201400", "167649");

            this.dataGridView4.Rows.Insert(8, "Temple of Exile", "201400", "135438");
            this.dataGridView4.Rows.Insert(9, "Moonlight 1", "132995", "87096");
            this.dataGridView4.Rows.Insert(10, "Moonlight 2", "130842", "79586");
            this.dataGridView4.Rows.Insert(11, "Lost Mine 1", "155817", "103724");

            this.dataGridView4.Rows.Insert(12, "Lost Mine 2", "152309", "102886");
            this.dataGridView4.Rows.Insert(13, "Crystal Valley 1", "103210", "100366");
            this.dataGridView4.Rows.Insert(14, "Crystal Valley 2", "99757", "103236");
            this.dataGridView4.Rows.Insert(15, "Palmir Plateau 1", "211302", "129971");

            this.dataGridView4.Rows.Insert(16, "Palmir Plateau 2", "211299", "146193");




        }

        private void button32_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("/run warp(" + xMap.Text + "," + yMap.Text + ")");
        }

        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow rowsz = dataGridView4.Rows[e.RowIndex];
            xMap.Text = rowsz.Cells[1].Value.ToString();
            yMap.Text = rowsz.Cells[2].Value.ToString();
        }

        private void dataGridView6_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow rowsz = dataGridView6.Rows[e.RowIndex];
            AddPet.Text = rowsz.Cells[0].Value.ToString();
            
        }
    }
}
