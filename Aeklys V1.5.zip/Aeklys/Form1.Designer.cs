﻿namespace Aeklys
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TabControl Buffs;
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "Fayz",
            "Fayz"}, -1);
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.firstlogin = new System.Windows.Forms.Panel();
            this.stringres = new System.Windows.Forms.TextBox();
            this.logbutton = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.UserBox = new System.Windows.Forms.TextBox();
            this.IpBox = new System.Windows.Forms.TextBox();
            this.ArcadiaBox = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.JobBox = new System.Windows.Forms.ComboBox();
            this.CreatureValue = new System.Windows.Forms.TextBox();
            this.CreatureListValue = new System.Windows.Forms.ComboBox();
            this.PlayerValueList = new System.Windows.Forms.ComboBox();
            this.PlayerValue = new System.Windows.Forms.TextBox();
            this.SlotCreature = new System.Windows.Forms.TextBox();
            this.Hunta = new System.Windows.Forms.TextBox();
            this.GOLD = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button17 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.GuildCDButton = new System.Windows.Forms.Button();
            this.GuildCD = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.kickplayer = new System.Windows.Forms.TextBox();
            this.flagdelete = new System.Windows.Forms.Button();
            this.deleteflag = new System.Windows.Forms.TextBox();
            this.SetFlagBt = new System.Windows.Forms.Button();
            this.FlagValue = new System.Windows.Forms.TextBox();
            this.FlagName = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Nameitem5 = new System.Windows.Forms.TextBox();
            this.searchengine = new System.Windows.Forms.TextBox();
            this.Iditem = new System.Windows.Forms.TextBox();
            this.ItemLevel = new System.Windows.Forms.TextBox();
            this.ItemEnchant = new System.Windows.Forms.TextBox();
            this.ItemAmmount = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button24 = new System.Windows.Forms.Button();
            this.GiveItem = new System.Windows.Forms.Button();
            this.Buff = new System.Windows.Forms.TabPage();
            this.BuffName = new System.Windows.Forms.TextBox();
            this.SearchM = new System.Windows.Forms.TextBox();
            this.IDBUFF = new System.Windows.Forms.TextBox();
            this.BuffTime = new System.Windows.Forms.TextBox();
            this.BuffLevel = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.nbMonster = new System.Windows.Forms.TextBox();
            this.NameMonster = new System.Windows.Forms.TextBox();
            this.SearchMonsters = new System.Windows.Forms.Button();
            this.SearchMEngine = new System.Windows.Forms.TextBox();
            this.IdMonster = new System.Windows.Forms.TextBox();
            this.GiveMonster = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button27 = new System.Windows.Forms.Button();
            this.SkillName = new System.Windows.Forms.TextBox();
            this.SkillSearch = new System.Windows.Forms.Button();
            this.SkillSearchEngine = new System.Windows.Forms.TextBox();
            this.SkillID = new System.Windows.Forms.TextBox();
            this.SkillGive = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button34 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button35 = new System.Windows.Forms.Button();
            this.Creature = new System.Windows.Forms.TabPage();
            this.stade = new System.Windows.Forms.Button();
            this.PetStade = new System.Windows.Forms.TextBox();
            this.PetStadeSlot = new System.Windows.Forms.TextBox();
            this.searchvaluepet = new System.Windows.Forms.TextBox();
            this.searchpet = new System.Windows.Forms.Button();
            this.AddPet = new System.Windows.Forms.TextBox();
            this.button29 = new System.Windows.Forms.Button();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button32 = new System.Windows.Forms.Button();
            this.yMap = new System.Windows.Forms.TextBox();
            this.xMap = new System.Windows.Forms.TextBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.x = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.y = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.listView1 = new System.Windows.Forms.ListView();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.ListNamed = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.TelecasterBox = new System.Windows.Forms.TextBox();
            this.button33 = new System.Windows.Forms.Button();
            Buffs = new System.Windows.Forms.TabControl();
            Buffs.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.firstlogin.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.Buff.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.Creature.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Buffs
            // 
            Buffs.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            Buffs.Controls.Add(this.tabPage1);
            Buffs.Controls.Add(this.tabPage2);
            Buffs.Controls.Add(this.Buff);
            Buffs.Controls.Add(this.tabPage3);
            Buffs.Controls.Add(this.tabPage4);
            Buffs.Controls.Add(this.tabPage7);
            Buffs.Controls.Add(this.Creature);
            Buffs.Controls.Add(this.tabPage5);
            Buffs.Controls.Add(this.tabPage8);
            Buffs.Controls.Add(this.tabPage6);
            Buffs.Location = new System.Drawing.Point(24, 12);
            Buffs.Name = "Buffs";
            Buffs.SelectedIndex = 0;
            Buffs.Size = new System.Drawing.Size(828, 500);
            Buffs.TabIndex = 27;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.firstlogin);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(820, 471);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "General";
            // 
            // firstlogin
            // 
            this.firstlogin.Controls.Add(this.TelecasterBox);
            this.firstlogin.Controls.Add(this.stringres);
            this.firstlogin.Controls.Add(this.logbutton);
            this.firstlogin.Controls.Add(this.textBox4);
            this.firstlogin.Controls.Add(this.UserBox);
            this.firstlogin.Controls.Add(this.IpBox);
            this.firstlogin.Controls.Add(this.ArcadiaBox);
            this.firstlogin.Location = new System.Drawing.Point(407, 293);
            this.firstlogin.Name = "firstlogin";
            this.firstlogin.Size = new System.Drawing.Size(390, 160);
            this.firstlogin.TabIndex = 4;
            // 
            // stringres
            // 
            this.stringres.Location = new System.Drawing.Point(123, 25);
            this.stringres.Name = "stringres";
            this.stringres.Size = new System.Drawing.Size(100, 20);
            this.stringres.TabIndex = 53;
            this.stringres.Text = "StringResource";
            this.stringres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // logbutton
            // 
            this.logbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.logbutton.Location = new System.Drawing.Point(120, 82);
            this.logbutton.Name = "logbutton";
            this.logbutton.Size = new System.Drawing.Size(101, 23);
            this.logbutton.TabIndex = 52;
            this.logbutton.Text = "Set Database";
            this.logbutton.UseVisualStyleBackColor = true;
            this.logbutton.Click += new System.EventHandler(this.logbutton_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(15, 111);
            this.textBox4.Name = "textBox4";
            this.textBox4.PasswordChar = '*';
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "*******";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // UserBox
            // 
            this.UserBox.Location = new System.Drawing.Point(15, 83);
            this.UserBox.Name = "UserBox";
            this.UserBox.Size = new System.Drawing.Size(100, 20);
            this.UserBox.TabIndex = 2;
            this.UserBox.Text = "sa";
            this.UserBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // IpBox
            // 
            this.IpBox.Location = new System.Drawing.Point(15, 25);
            this.IpBox.Name = "IpBox";
            this.IpBox.Size = new System.Drawing.Size(100, 20);
            this.IpBox.TabIndex = 1;
            this.IpBox.Text = "127.0.0.1";
            this.IpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ArcadiaBox
            // 
            this.ArcadiaBox.Location = new System.Drawing.Point(15, 54);
            this.ArcadiaBox.Name = "ArcadiaBox";
            this.ArcadiaBox.Size = new System.Drawing.Size(100, 20);
            this.ArcadiaBox.TabIndex = 0;
            this.ArcadiaBox.Text = "Arcadia";
            this.ArcadiaBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.JobBox);
            this.panel1.Controls.Add(this.CreatureValue);
            this.panel1.Controls.Add(this.CreatureListValue);
            this.panel1.Controls.Add(this.PlayerValueList);
            this.panel1.Controls.Add(this.PlayerValue);
            this.panel1.Controls.Add(this.SlotCreature);
            this.panel1.Controls.Add(this.Hunta);
            this.panel1.Controls.Add(this.GOLD);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.ForeColor = System.Drawing.Color.Coral;
            this.panel1.Location = new System.Drawing.Point(15, 19);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(372, 264);
            this.panel1.TabIndex = 0;
            // 
            // JobBox
            // 
            this.JobBox.BackColor = System.Drawing.Color.YellowGreen;
            this.JobBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.JobBox.FormattingEnabled = true;
            this.JobBox.Items.AddRange(new object[] {
            "Rogue",
            "Fighter",
            "Kahuna",
            "Spell Singer",
            "Champion",
            "Archer",
            "Druid",
            "Battle Kahuna",
            "Evoker",
            "Berserker",
            "Marksman",
            "Magus",
            "War Kahuna",
            "Beast Master",
            "Guide",
            "Holy Warrior",
            "Cleric",
            "Breeder",
            "Knight",
            "Soldier",
            "Bishop",
            "Priest",
            "Soul Breeder",
            "Templar",
            "Mercenary",
            "Cardinal",
            "Oracle",
            "Master Breeder",
            "Stepper",
            "Strider",
            "Dark Magician",
            "Sorcerer",
            "Assassin",
            "Shadow Hunter",
            "Chaos Magician",
            "Warlock",
            "Battle Summoner",
            "Slayer",
            "Deadeye",
            "Void Mage",
            "Corruptor",
            "Overlord"});
            this.JobBox.Location = new System.Drawing.Point(13, 185);
            this.JobBox.Name = "JobBox";
            this.JobBox.Size = new System.Drawing.Size(251, 21);
            this.JobBox.TabIndex = 13;
            this.JobBox.Text = "Job";
            // 
            // CreatureValue
            // 
            this.CreatureValue.BackColor = System.Drawing.Color.YellowGreen;
            this.CreatureValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CreatureValue.Location = new System.Drawing.Point(135, 144);
            this.CreatureValue.Name = "CreatureValue";
            this.CreatureValue.Size = new System.Drawing.Size(65, 20);
            this.CreatureValue.TabIndex = 12;
            this.CreatureValue.Text = "100";
            this.CreatureValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CreatureListValue
            // 
            this.CreatureListValue.BackColor = System.Drawing.Color.YellowGreen;
            this.CreatureListValue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CreatureListValue.FormattingEnabled = true;
            this.CreatureListValue.Location = new System.Drawing.Point(13, 143);
            this.CreatureListValue.Name = "CreatureListValue";
            this.CreatureListValue.Size = new System.Drawing.Size(116, 21);
            this.CreatureListValue.TabIndex = 11;
            this.CreatureListValue.Text = "lv";
            // 
            // PlayerValueList
            // 
            this.PlayerValueList.BackColor = System.Drawing.Color.YellowGreen;
            this.PlayerValueList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PlayerValueList.FormattingEnabled = true;
            this.PlayerValueList.Location = new System.Drawing.Point(13, 108);
            this.PlayerValueList.Name = "PlayerValueList";
            this.PlayerValueList.Size = new System.Drawing.Size(116, 21);
            this.PlayerValueList.TabIndex = 3;
            this.PlayerValueList.Text = "lv";
            // 
            // PlayerValue
            // 
            this.PlayerValue.BackColor = System.Drawing.Color.YellowGreen;
            this.PlayerValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PlayerValue.Location = new System.Drawing.Point(135, 108);
            this.PlayerValue.Name = "PlayerValue";
            this.PlayerValue.Size = new System.Drawing.Size(129, 20);
            this.PlayerValue.TabIndex = 10;
            this.PlayerValue.Text = "100";
            this.PlayerValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SlotCreature
            // 
            this.SlotCreature.BackColor = System.Drawing.Color.YellowGreen;
            this.SlotCreature.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SlotCreature.Location = new System.Drawing.Point(206, 144);
            this.SlotCreature.Name = "SlotCreature";
            this.SlotCreature.Size = new System.Drawing.Size(58, 20);
            this.SlotCreature.TabIndex = 9;
            this.SlotCreature.Text = "(Slot)";
            this.SlotCreature.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Hunta
            // 
            this.Hunta.BackColor = System.Drawing.Color.YellowGreen;
            this.Hunta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hunta.Location = new System.Drawing.Point(13, 68);
            this.Hunta.Name = "Hunta";
            this.Hunta.Size = new System.Drawing.Size(251, 20);
            this.Hunta.TabIndex = 8;
            this.Hunta.Text = "99999999";
            this.Hunta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GOLD
            // 
            this.GOLD.BackColor = System.Drawing.Color.YellowGreen;
            this.GOLD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.GOLD.Location = new System.Drawing.Point(13, 27);
            this.GOLD.Name = "GOLD";
            this.GOLD.Size = new System.Drawing.Size(251, 20);
            this.GOLD.TabIndex = 7;
            this.GOLD.Text = "99999999";
            this.GOLD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button7
            // 
            this.button7.BackgroundImage = global::Aeklys.Properties.Resources.set_gold7;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button7.Location = new System.Drawing.Point(94, 221);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 6;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackgroundImage = global::Aeklys.Properties.Resources.set_gold6;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button6.Location = new System.Drawing.Point(13, 221);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 5;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::Aeklys.Properties.Resources.set_gold5;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button5.Location = new System.Drawing.Point(270, 183);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 4;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::Aeklys.Properties.Resources.set_gold4;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.Location = new System.Drawing.Point(270, 144);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::Aeklys.Properties.Resources.set_gold3;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.Location = new System.Drawing.Point(270, 106);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::Aeklys.Properties.Resources.set_gold2;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(270, 65);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Aeklys.Properties.Resources.set_gold1;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(270, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.button17);
            this.panel2.Controls.Add(this.button14);
            this.panel2.Controls.Add(this.button15);
            this.panel2.Controls.Add(this.button16);
            this.panel2.Controls.Add(this.button11);
            this.panel2.Controls.Add(this.button12);
            this.panel2.Controls.Add(this.button13);
            this.panel2.Controls.Add(this.button10);
            this.panel2.Controls.Add(this.button9);
            this.panel2.Controls.Add(this.button8);
            this.panel2.Location = new System.Drawing.Point(15, 293);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(372, 160);
            this.panel2.TabIndex = 1;
            // 
            // button17
            // 
            this.button17.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button17.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button17.Location = new System.Drawing.Point(27, 107);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(102, 23);
            this.button17.TabIndex = 16;
            this.button17.Text = "Soulstone (Repair)";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button14
            // 
            this.button14.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button14.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button14.Location = new System.Drawing.Point(243, 78);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(102, 23);
            this.button14.TabIndex = 15;
            this.button14.Text = "Soulstone (Craft)";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button15.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button15.Location = new System.Drawing.Point(135, 78);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(102, 23);
            this.button15.TabIndex = 14;
            this.button15.Text = "Dungeon Stone";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button16.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button16.Location = new System.Drawing.Point(27, 78);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(102, 23);
            this.button16.TabIndex = 13;
            this.button16.Text = "Ursa Lobby";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button11
            // 
            this.button11.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button11.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button11.Location = new System.Drawing.Point(243, 49);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(102, 23);
            this.button11.TabIndex = 12;
            this.button11.Text = "C. Change Name";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button12.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button12.Location = new System.Drawing.Point(135, 49);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(102, 23);
            this.button12.TabIndex = 11;
            this.button12.Text = "Alliance";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackgroundImage = global::Aeklys.Properties.Resources.text3;
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button13.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button13.Location = new System.Drawing.Point(27, 49);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(102, 23);
            this.button13.TabIndex = 10;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button10
            // 
            this.button10.BackgroundImage = global::Aeklys.Properties.Resources.text2;
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button10.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button10.Location = new System.Drawing.Point(243, 20);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(102, 23);
            this.button10.TabIndex = 9;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::Aeklys.Properties.Resources.text1;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button9.Location = new System.Drawing.Point(135, 20);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(102, 23);
            this.button9.TabIndex = 8;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.BackgroundImage = global::Aeklys.Properties.Resources.text;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button8.Location = new System.Drawing.Point(27, 20);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(102, 23);
            this.button8.TabIndex = 7;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.button31);
            this.panel3.Controls.Add(this.button30);
            this.panel3.Controls.Add(this.textBox6);
            this.panel3.Controls.Add(this.button21);
            this.panel3.Controls.Add(this.button20);
            this.panel3.Controls.Add(this.button19);
            this.panel3.Controls.Add(this.GuildCDButton);
            this.panel3.Controls.Add(this.GuildCD);
            this.panel3.Controls.Add(this.button18);
            this.panel3.Controls.Add(this.kickplayer);
            this.panel3.Controls.Add(this.flagdelete);
            this.panel3.Controls.Add(this.deleteflag);
            this.panel3.Controls.Add(this.SetFlagBt);
            this.panel3.Controls.Add(this.FlagValue);
            this.panel3.Controls.Add(this.FlagName);
            this.panel3.Location = new System.Drawing.Point(393, 19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(404, 264);
            this.panel3.TabIndex = 3;
            // 
            // button31
            // 
            this.button31.BackgroundImage = global::Aeklys.Properties.Resources.text5;
            this.button31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button31.Location = new System.Drawing.Point(327, 221);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(68, 23);
            this.button31.TabIndex = 27;
            this.button31.Text = "KillTarget";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button30
            // 
            this.button30.BackgroundImage = global::Aeklys.Properties.Resources.text6;
            this.button30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button30.Location = new System.Drawing.Point(284, 100);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 23);
            this.button30.TabIndex = 26;
            this.button30.Text = "Go";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Location = new System.Drawing.Point(12, 103);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(256, 20);
            this.textBox6.TabIndex = 25;
            this.textBox6.Text = "Announce";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button21
            // 
            this.button21.BackgroundImage = global::Aeklys.Properties.Resources.text5;
            this.button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button21.Location = new System.Drawing.Point(222, 221);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(99, 23);
            this.button21.TabIndex = 24;
            this.button21.Text = "Save";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button20
            // 
            this.button20.BackgroundImage = global::Aeklys.Properties.Resources.text5;
            this.button20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button20.Location = new System.Drawing.Point(12, 221);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(99, 23);
            this.button20.TabIndex = 23;
            this.button20.Text = "Warp to revive";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button19
            // 
            this.button19.BackgroundImage = global::Aeklys.Properties.Resources.text5;
            this.button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button19.Location = new System.Drawing.Point(117, 221);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(99, 23);
            this.button19.TabIndex = 22;
            this.button19.Text = "Recall Player";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // GuildCDButton
            // 
            this.GuildCDButton.BackgroundImage = global::Aeklys.Properties.Resources.text6;
            this.GuildCDButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.GuildCDButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GuildCDButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.GuildCDButton.Location = new System.Drawing.Point(284, 144);
            this.GuildCDButton.Name = "GuildCDButton";
            this.GuildCDButton.Size = new System.Drawing.Size(75, 23);
            this.GuildCDButton.TabIndex = 21;
            this.GuildCDButton.Text = "Guild CD";
            this.GuildCDButton.UseVisualStyleBackColor = true;
            this.GuildCDButton.Click += new System.EventHandler(this.GuildCDButton_Click);
            // 
            // GuildCD
            // 
            this.GuildCD.BackColor = System.Drawing.Color.YellowGreen;
            this.GuildCD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.GuildCD.Location = new System.Drawing.Point(12, 146);
            this.GuildCD.Name = "GuildCD";
            this.GuildCD.Size = new System.Drawing.Size(256, 20);
            this.GuildCD.TabIndex = 20;
            this.GuildCD.Text = "Guild cooldown ( In second )";
            this.GuildCD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button18
            // 
            this.button18.BackgroundImage = global::Aeklys.Properties.Resources.text6;
            this.button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button18.Location = new System.Drawing.Point(284, 183);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 23);
            this.button18.TabIndex = 19;
            this.button18.Text = "Kick";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // kickplayer
            // 
            this.kickplayer.BackColor = System.Drawing.Color.YellowGreen;
            this.kickplayer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.kickplayer.Location = new System.Drawing.Point(12, 183);
            this.kickplayer.Name = "kickplayer";
            this.kickplayer.Size = new System.Drawing.Size(256, 20);
            this.kickplayer.TabIndex = 18;
            this.kickplayer.Text = "PlayerName";
            this.kickplayer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // flagdelete
            // 
            this.flagdelete.BackgroundImage = global::Aeklys.Properties.Resources.text6;
            this.flagdelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.flagdelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.flagdelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.flagdelete.Location = new System.Drawing.Point(284, 68);
            this.flagdelete.Name = "flagdelete";
            this.flagdelete.Size = new System.Drawing.Size(75, 23);
            this.flagdelete.TabIndex = 17;
            this.flagdelete.Text = "Delete flag";
            this.flagdelete.UseVisualStyleBackColor = true;
            this.flagdelete.Click += new System.EventHandler(this.flagdelete_Click);
            // 
            // deleteflag
            // 
            this.deleteflag.BackColor = System.Drawing.Color.YellowGreen;
            this.deleteflag.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.deleteflag.Location = new System.Drawing.Point(12, 67);
            this.deleteflag.Name = "deleteflag";
            this.deleteflag.Size = new System.Drawing.Size(256, 20);
            this.deleteflag.TabIndex = 16;
            this.deleteflag.Text = "flag_name";
            this.deleteflag.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SetFlagBt
            // 
            this.SetFlagBt.BackgroundImage = global::Aeklys.Properties.Resources.text6;
            this.SetFlagBt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SetFlagBt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SetFlagBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.SetFlagBt.Location = new System.Drawing.Point(284, 28);
            this.SetFlagBt.Name = "SetFlagBt";
            this.SetFlagBt.Size = new System.Drawing.Size(75, 23);
            this.SetFlagBt.TabIndex = 14;
            this.SetFlagBt.Text = "Set Flag";
            this.SetFlagBt.UseVisualStyleBackColor = true;
            this.SetFlagBt.Click += new System.EventHandler(this.SetFlagBt_Click);
            // 
            // FlagValue
            // 
            this.FlagValue.BackColor = System.Drawing.Color.YellowGreen;
            this.FlagValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FlagValue.Location = new System.Drawing.Point(153, 28);
            this.FlagValue.Name = "FlagValue";
            this.FlagValue.Size = new System.Drawing.Size(115, 20);
            this.FlagValue.TabIndex = 15;
            this.FlagValue.Text = "Value";
            this.FlagValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FlagName
            // 
            this.FlagName.BackColor = System.Drawing.Color.YellowGreen;
            this.FlagName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FlagName.Location = new System.Drawing.Point(12, 27);
            this.FlagName.Name = "FlagName";
            this.FlagName.Size = new System.Drawing.Size(115, 20);
            this.FlagName.TabIndex = 14;
            this.FlagName.Text = "flag_name";
            this.FlagName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Nameitem5);
            this.tabPage2.Controls.Add(this.searchengine);
            this.tabPage2.Controls.Add(this.Iditem);
            this.tabPage2.Controls.Add(this.ItemLevel);
            this.tabPage2.Controls.Add(this.ItemEnchant);
            this.tabPage2.Controls.Add(this.ItemAmmount);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Controls.Add(this.button24);
            this.tabPage2.Controls.Add(this.GiveItem);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(820, 471);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Items";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Nameitem5
            // 
            this.Nameitem5.BackColor = System.Drawing.Color.YellowGreen;
            this.Nameitem5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Nameitem5.Cursor = System.Windows.Forms.Cursors.Default;
            this.Nameitem5.Location = new System.Drawing.Point(3, 446);
            this.Nameitem5.Name = "Nameitem5";
            this.Nameitem5.Size = new System.Drawing.Size(540, 20);
            this.Nameitem5.TabIndex = 30;
            this.Nameitem5.Text = "Selected Item Name";
            this.Nameitem5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // searchengine
            // 
            this.searchengine.BackColor = System.Drawing.Color.YellowGreen;
            this.searchengine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchengine.Location = new System.Drawing.Point(699, 442);
            this.searchengine.Name = "searchengine";
            this.searchengine.Size = new System.Drawing.Size(115, 20);
            this.searchengine.TabIndex = 28;
            this.searchengine.Text = "Name";
            this.searchengine.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Iditem
            // 
            this.Iditem.BackColor = System.Drawing.Color.YellowGreen;
            this.Iditem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Iditem.Location = new System.Drawing.Point(3, 423);
            this.Iditem.Name = "Iditem";
            this.Iditem.Size = new System.Drawing.Size(115, 20);
            this.Iditem.TabIndex = 27;
            this.Iditem.Text = "ID";
            this.Iditem.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ItemLevel
            // 
            this.ItemLevel.BackColor = System.Drawing.Color.YellowGreen;
            this.ItemLevel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ItemLevel.Location = new System.Drawing.Point(366, 423);
            this.ItemLevel.Name = "ItemLevel";
            this.ItemLevel.Size = new System.Drawing.Size(115, 20);
            this.ItemLevel.TabIndex = 17;
            this.ItemLevel.Text = "Level";
            this.ItemLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ItemEnchant
            // 
            this.ItemEnchant.BackColor = System.Drawing.Color.YellowGreen;
            this.ItemEnchant.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ItemEnchant.Location = new System.Drawing.Point(245, 423);
            this.ItemEnchant.Name = "ItemEnchant";
            this.ItemEnchant.Size = new System.Drawing.Size(115, 20);
            this.ItemEnchant.TabIndex = 16;
            this.ItemEnchant.Text = "Enchant";
            this.ItemEnchant.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ItemAmmount
            // 
            this.ItemAmmount.BackColor = System.Drawing.Color.YellowGreen;
            this.ItemAmmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ItemAmmount.Location = new System.Drawing.Point(124, 423);
            this.ItemAmmount.Name = "ItemAmmount";
            this.ItemAmmount.Size = new System.Drawing.Size(115, 20);
            this.ItemAmmount.TabIndex = 15;
            this.ItemAmmount.Text = "Ammount";
            this.ItemAmmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(808, 414);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellClick);
            // 
            // button24
            // 
            this.button24.BackgroundImage = global::Aeklys.Properties.Resources.text7;
            this.button24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(637, 442);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(56, 23);
            this.button24.TabIndex = 29;
            this.button24.Text = "Search";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // GiveItem
            // 
            this.GiveItem.BackgroundImage = global::Aeklys.Properties.Resources.text7;
            this.GiveItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.GiveItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GiveItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.GiveItem.Location = new System.Drawing.Point(487, 421);
            this.GiveItem.Name = "GiveItem";
            this.GiveItem.Size = new System.Drawing.Size(56, 23);
            this.GiveItem.TabIndex = 26;
            this.GiveItem.Text = "Give";
            this.GiveItem.UseVisualStyleBackColor = true;
            this.GiveItem.Click += new System.EventHandler(this.GiveItem_Click);
            // 
            // Buff
            // 
            this.Buff.Controls.Add(this.BuffName);
            this.Buff.Controls.Add(this.SearchM);
            this.Buff.Controls.Add(this.IDBUFF);
            this.Buff.Controls.Add(this.BuffTime);
            this.Buff.Controls.Add(this.BuffLevel);
            this.Buff.Controls.Add(this.dataGridView2);
            this.Buff.Controls.Add(this.button25);
            this.Buff.Controls.Add(this.button26);
            this.Buff.Location = new System.Drawing.Point(4, 25);
            this.Buff.Name = "Buff";
            this.Buff.Padding = new System.Windows.Forms.Padding(3);
            this.Buff.Size = new System.Drawing.Size(820, 471);
            this.Buff.TabIndex = 2;
            this.Buff.Text = "Buffs";
            this.Buff.UseVisualStyleBackColor = true;
            // 
            // BuffName
            // 
            this.BuffName.BackColor = System.Drawing.Color.YellowGreen;
            this.BuffName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BuffName.Location = new System.Drawing.Point(8, 449);
            this.BuffName.Name = "BuffName";
            this.BuffName.Size = new System.Drawing.Size(540, 20);
            this.BuffName.TabIndex = 38;
            this.BuffName.Text = "Selected buff Name";
            this.BuffName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SearchM
            // 
            this.SearchM.BackColor = System.Drawing.Color.YellowGreen;
            this.SearchM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchM.Location = new System.Drawing.Point(701, 447);
            this.SearchM.Name = "SearchM";
            this.SearchM.Size = new System.Drawing.Size(115, 20);
            this.SearchM.TabIndex = 36;
            this.SearchM.Text = "Name";
            this.SearchM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // IDBUFF
            // 
            this.IDBUFF.BackColor = System.Drawing.Color.YellowGreen;
            this.IDBUFF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IDBUFF.Location = new System.Drawing.Point(8, 426);
            this.IDBUFF.Name = "IDBUFF";
            this.IDBUFF.Size = new System.Drawing.Size(115, 20);
            this.IDBUFF.TabIndex = 35;
            this.IDBUFF.Text = "ID";
            this.IDBUFF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BuffTime
            // 
            this.BuffTime.BackColor = System.Drawing.Color.YellowGreen;
            this.BuffTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BuffTime.Location = new System.Drawing.Point(250, 426);
            this.BuffTime.Name = "BuffTime";
            this.BuffTime.Size = new System.Drawing.Size(115, 20);
            this.BuffTime.TabIndex = 32;
            this.BuffTime.Text = "Time (Minutes)";
            this.BuffTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BuffLevel
            // 
            this.BuffLevel.BackColor = System.Drawing.Color.YellowGreen;
            this.BuffLevel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BuffLevel.Location = new System.Drawing.Point(129, 426);
            this.BuffLevel.Name = "BuffLevel";
            this.BuffLevel.Size = new System.Drawing.Size(115, 20);
            this.BuffLevel.TabIndex = 31;
            this.BuffLevel.Text = "BuffLevel";
            this.BuffLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 6);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(808, 414);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // button25
            // 
            this.button25.BackgroundImage = global::Aeklys.Properties.Resources.text7;
            this.button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button25.Location = new System.Drawing.Point(639, 447);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(56, 23);
            this.button25.TabIndex = 37;
            this.button25.Text = "Search";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.BackgroundImage = global::Aeklys.Properties.Resources.text7;
            this.button26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(492, 424);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(56, 23);
            this.button26.TabIndex = 34;
            this.button26.Text = "Give";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.nbMonster);
            this.tabPage3.Controls.Add(this.NameMonster);
            this.tabPage3.Controls.Add(this.SearchMonsters);
            this.tabPage3.Controls.Add(this.SearchMEngine);
            this.tabPage3.Controls.Add(this.IdMonster);
            this.tabPage3.Controls.Add(this.GiveMonster);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(820, 471);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "Monster";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // nbMonster
            // 
            this.nbMonster.BackColor = System.Drawing.Color.YellowGreen;
            this.nbMonster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nbMonster.Location = new System.Drawing.Point(127, 428);
            this.nbMonster.Name = "nbMonster";
            this.nbMonster.Size = new System.Drawing.Size(115, 20);
            this.nbMonster.TabIndex = 46;
            this.nbMonster.Text = "Ammount";
            this.nbMonster.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NameMonster
            // 
            this.NameMonster.BackColor = System.Drawing.Color.YellowGreen;
            this.NameMonster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NameMonster.Location = new System.Drawing.Point(6, 451);
            this.NameMonster.Name = "NameMonster";
            this.NameMonster.Size = new System.Drawing.Size(540, 20);
            this.NameMonster.TabIndex = 45;
            this.NameMonster.Text = "Selected Monster Name";
            this.NameMonster.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SearchMonsters
            // 
            this.SearchMonsters.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.SearchMonsters.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SearchMonsters.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchMonsters.Location = new System.Drawing.Point(637, 449);
            this.SearchMonsters.Name = "SearchMonsters";
            this.SearchMonsters.Size = new System.Drawing.Size(56, 23);
            this.SearchMonsters.TabIndex = 44;
            this.SearchMonsters.Text = "Search";
            this.SearchMonsters.UseVisualStyleBackColor = true;
            this.SearchMonsters.Click += new System.EventHandler(this.SearchMonsters_Click);
            // 
            // SearchMEngine
            // 
            this.SearchMEngine.BackColor = System.Drawing.Color.YellowGreen;
            this.SearchMEngine.Location = new System.Drawing.Point(699, 449);
            this.SearchMEngine.Name = "SearchMEngine";
            this.SearchMEngine.Size = new System.Drawing.Size(115, 20);
            this.SearchMEngine.TabIndex = 43;
            this.SearchMEngine.Text = "Name";
            this.SearchMEngine.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // IdMonster
            // 
            this.IdMonster.BackColor = System.Drawing.Color.YellowGreen;
            this.IdMonster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IdMonster.Location = new System.Drawing.Point(6, 428);
            this.IdMonster.Name = "IdMonster";
            this.IdMonster.Size = new System.Drawing.Size(115, 20);
            this.IdMonster.TabIndex = 42;
            this.IdMonster.Text = "ID";
            this.IdMonster.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GiveMonster
            // 
            this.GiveMonster.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.GiveMonster.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.GiveMonster.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GiveMonster.Location = new System.Drawing.Point(248, 426);
            this.GiveMonster.Name = "GiveMonster";
            this.GiveMonster.Size = new System.Drawing.Size(67, 23);
            this.GiveMonster.TabIndex = 41;
            this.GiveMonster.Text = "Summon";
            this.GiveMonster.UseVisualStyleBackColor = true;
            this.GiveMonster.Click += new System.EventHandler(this.GiveMonster_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(6, 6);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(808, 414);
            this.dataGridView3.TabIndex = 2;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellClick);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button27);
            this.tabPage4.Controls.Add(this.SkillName);
            this.tabPage4.Controls.Add(this.SkillSearch);
            this.tabPage4.Controls.Add(this.SkillSearchEngine);
            this.tabPage4.Controls.Add(this.SkillID);
            this.tabPage4.Controls.Add(this.SkillGive);
            this.tabPage4.Controls.Add(this.dataGridView5);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(820, 471);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "Skills";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(189, 423);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(101, 23);
            this.button27.TabIndex = 51;
            this.button27.Text = "Creature Learn";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // SkillName
            // 
            this.SkillName.BackColor = System.Drawing.Color.YellowGreen;
            this.SkillName.Location = new System.Drawing.Point(6, 448);
            this.SkillName.Name = "SkillName";
            this.SkillName.Size = new System.Drawing.Size(540, 20);
            this.SkillName.TabIndex = 50;
            this.SkillName.Text = "Selected Skill Name";
            this.SkillName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SkillSearch
            // 
            this.SkillSearch.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.SkillSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SkillSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SkillSearch.Location = new System.Drawing.Point(637, 446);
            this.SkillSearch.Name = "SkillSearch";
            this.SkillSearch.Size = new System.Drawing.Size(56, 23);
            this.SkillSearch.TabIndex = 49;
            this.SkillSearch.Text = "Search";
            this.SkillSearch.UseVisualStyleBackColor = true;
            this.SkillSearch.Click += new System.EventHandler(this.SkillSearch_Click);
            // 
            // SkillSearchEngine
            // 
            this.SkillSearchEngine.BackColor = System.Drawing.Color.YellowGreen;
            this.SkillSearchEngine.Location = new System.Drawing.Point(699, 446);
            this.SkillSearchEngine.Name = "SkillSearchEngine";
            this.SkillSearchEngine.Size = new System.Drawing.Size(115, 20);
            this.SkillSearchEngine.TabIndex = 48;
            this.SkillSearchEngine.Text = "Name";
            this.SkillSearchEngine.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SkillID
            // 
            this.SkillID.BackColor = System.Drawing.Color.YellowGreen;
            this.SkillID.Location = new System.Drawing.Point(6, 425);
            this.SkillID.Name = "SkillID";
            this.SkillID.Size = new System.Drawing.Size(115, 20);
            this.SkillID.TabIndex = 47;
            this.SkillID.Text = "ID";
            this.SkillID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SkillGive
            // 
            this.SkillGive.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.SkillGive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SkillGive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SkillGive.Location = new System.Drawing.Point(127, 423);
            this.SkillGive.Name = "SkillGive";
            this.SkillGive.Size = new System.Drawing.Size(56, 23);
            this.SkillGive.TabIndex = 46;
            this.SkillGive.Text = "Learn";
            this.SkillGive.UseVisualStyleBackColor = true;
            this.SkillGive.Click += new System.EventHandler(this.SkillGive_Click);
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(3, 6);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(808, 414);
            this.dataGridView5.TabIndex = 3;
            this.dataGridView5.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellClick);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.dataGridView7);
            this.tabPage7.Controls.Add(this.textBox1);
            this.tabPage7.Controls.Add(this.button34);
            this.tabPage7.Controls.Add(this.textBox3);
            this.tabPage7.Controls.Add(this.textBox5);
            this.tabPage7.Controls.Add(this.button35);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(820, 471);
            this.tabPage7.TabIndex = 8;
            this.tabPage7.Text = "Title";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // dataGridView7
            // 
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Location = new System.Drawing.Point(3, 6);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.Size = new System.Drawing.Size(808, 414);
            this.dataGridView7.TabIndex = 58;
            this.dataGridView7.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView7_CellContentClick);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox1.Location = new System.Drawing.Point(6, 445);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(540, 20);
            this.textBox1.TabIndex = 56;
            this.textBox1.Text = "Selected Skill Name";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button34
            // 
            this.button34.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.button34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(637, 443);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(56, 23);
            this.button34.TabIndex = 55;
            this.button34.Text = "Search";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox3.Location = new System.Drawing.Point(699, 443);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(115, 20);
            this.textBox3.TabIndex = 54;
            this.textBox3.Text = "Name";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox5.Location = new System.Drawing.Point(6, 422);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(115, 20);
            this.textBox5.TabIndex = 53;
            this.textBox5.Text = "ID";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button35
            // 
            this.button35.BackgroundImage = global::Aeklys.Properties.Resources.text4;
            this.button35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(127, 420);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(56, 23);
            this.button35.TabIndex = 52;
            this.button35.Text = "Learn";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // Creature
            // 
            this.Creature.Controls.Add(this.stade);
            this.Creature.Controls.Add(this.PetStade);
            this.Creature.Controls.Add(this.PetStadeSlot);
            this.Creature.Controls.Add(this.searchvaluepet);
            this.Creature.Controls.Add(this.searchpet);
            this.Creature.Controls.Add(this.AddPet);
            this.Creature.Controls.Add(this.button29);
            this.Creature.Controls.Add(this.dataGridView6);
            this.Creature.Location = new System.Drawing.Point(4, 25);
            this.Creature.Name = "Creature";
            this.Creature.Padding = new System.Windows.Forms.Padding(3);
            this.Creature.Size = new System.Drawing.Size(820, 471);
            this.Creature.TabIndex = 7;
            this.Creature.Text = "Creature";
            this.Creature.UseVisualStyleBackColor = true;
            // 
            // stade
            // 
            this.stade.BackgroundImage = global::Aeklys.Properties.Resources.text7;
            this.stade.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.stade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.stade.Location = new System.Drawing.Point(418, 426);
            this.stade.Name = "stade";
            this.stade.Size = new System.Drawing.Size(56, 23);
            this.stade.TabIndex = 33;
            this.stade.Text = "Go";
            this.stade.UseVisualStyleBackColor = true;
            this.stade.Click += new System.EventHandler(this.stade_Click);
            // 
            // PetStade
            // 
            this.PetStade.BackColor = System.Drawing.Color.YellowGreen;
            this.PetStade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PetStade.Location = new System.Drawing.Point(360, 427);
            this.PetStade.Name = "PetStade";
            this.PetStade.Size = new System.Drawing.Size(52, 20);
            this.PetStade.TabIndex = 32;
            this.PetStade.Text = "1,2,3,4,5";
            this.PetStade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PetStadeSlot
            // 
            this.PetStadeSlot.BackColor = System.Drawing.Color.YellowGreen;
            this.PetStadeSlot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PetStadeSlot.Location = new System.Drawing.Point(302, 427);
            this.PetStadeSlot.Name = "PetStadeSlot";
            this.PetStadeSlot.Size = new System.Drawing.Size(52, 20);
            this.PetStadeSlot.TabIndex = 31;
            this.PetStadeSlot.Text = "Slot";
            this.PetStadeSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // searchvaluepet
            // 
            this.searchvaluepet.BackColor = System.Drawing.Color.YellowGreen;
            this.searchvaluepet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchvaluepet.Location = new System.Drawing.Point(637, 425);
            this.searchvaluepet.Name = "searchvaluepet";
            this.searchvaluepet.Size = new System.Drawing.Size(115, 20);
            this.searchvaluepet.TabIndex = 29;
            this.searchvaluepet.Text = "Value";
            this.searchvaluepet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // searchpet
            // 
            this.searchpet.BackgroundImage = global::Aeklys.Properties.Resources.text7;
            this.searchpet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.searchpet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchpet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.searchpet.Location = new System.Drawing.Point(758, 423);
            this.searchpet.Name = "searchpet";
            this.searchpet.Size = new System.Drawing.Size(56, 23);
            this.searchpet.TabIndex = 30;
            this.searchpet.Text = "Search";
            this.searchpet.UseVisualStyleBackColor = true;
            this.searchpet.Click += new System.EventHandler(this.searchpet_Click);
            // 
            // AddPet
            // 
            this.AddPet.BackColor = System.Drawing.Color.YellowGreen;
            this.AddPet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AddPet.Location = new System.Drawing.Point(9, 426);
            this.AddPet.Name = "AddPet";
            this.AddPet.Size = new System.Drawing.Size(115, 20);
            this.AddPet.TabIndex = 27;
            this.AddPet.Text = "ID";
            this.AddPet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button29
            // 
            this.button29.BackgroundImage = global::Aeklys.Properties.Resources.text7;
            this.button29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button29.Location = new System.Drawing.Point(130, 424);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(56, 23);
            this.button29.TabIndex = 28;
            this.button29.Text = "Give";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(9, 6);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(808, 414);
            this.dataGridView6.TabIndex = 4;
            this.dataGridView6.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellContentClick);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button32);
            this.tabPage5.Controls.Add(this.yMap);
            this.tabPage5.Controls.Add(this.xMap);
            this.tabPage5.Controls.Add(this.dataGridView4);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(820, 471);
            this.tabPage5.TabIndex = 5;
            this.tabPage5.Text = "Warps";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.BackgroundImage = global::Aeklys.Properties.Resources.text7;
            this.button32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button32.Location = new System.Drawing.Point(134, 426);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(56, 23);
            this.button32.TabIndex = 36;
            this.button32.Text = "Go";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // yMap
            // 
            this.yMap.BackColor = System.Drawing.Color.YellowGreen;
            this.yMap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yMap.Location = new System.Drawing.Point(76, 427);
            this.yMap.Name = "yMap";
            this.yMap.Size = new System.Drawing.Size(52, 20);
            this.yMap.TabIndex = 35;
            this.yMap.Text = "y";
            this.yMap.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // xMap
            // 
            this.xMap.BackColor = System.Drawing.Color.YellowGreen;
            this.xMap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.xMap.Location = new System.Drawing.Point(18, 427);
            this.xMap.Name = "xMap";
            this.xMap.Size = new System.Drawing.Size(52, 20);
            this.xMap.TabIndex = 34;
            this.xMap.Text = "x";
            this.xMap.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name,
            this.x,
            this.y});
            this.dataGridView4.Location = new System.Drawing.Point(6, 6);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(808, 414);
            this.dataGridView4.TabIndex = 2;
            this.dataGridView4.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellClick);
            // 
            // name
            // 
            this.name.HeaderText = "name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // x
            // 
            this.x.HeaderText = "x";
            this.x.Name = "x";
            this.x.ReadOnly = true;
            // 
            // y
            // 
            this.y.HeaderText = "y";
            this.y.Name = "y";
            this.y.ReadOnly = true;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.button33);
            this.tabPage8.Controls.Add(this.dataGridView8);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(820, 471);
            this.tabPage8.TabIndex = 9;
            this.tabPage8.Text = "Character";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // dataGridView8
            // 
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Location = new System.Drawing.Point(6, 6);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.Size = new System.Drawing.Size(808, 440);
            this.dataGridView8.TabIndex = 3;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.pictureBox1);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(820, 471);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "About";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Aeklys.Properties.Resources.Light;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(820, 474);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // listView1
            // 
            this.listView1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.listView1.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listView1.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.listView1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.listView1.AutoArrange = false;
            this.listView1.ContextMenuStrip = this.contextMenuStrip1;
            this.listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.listView1.HideSelection = false;
            listViewItem2.Checked = true;
            listViewItem2.StateImageIndex = 1;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem2});
            this.listView1.LabelWrap = false;
            this.listView1.Location = new System.Drawing.Point(868, 34);
            this.listView1.Margin = new System.Windows.Forms.Padding(0);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(121, 420);
            this.listView1.TabIndex = 0;
            this.listView1.TabStop = false;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // button22
            // 
            this.button22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button22.Location = new System.Drawing.Point(868, 460);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(56, 23);
            this.button22.TabIndex = 25;
            this.button22.Text = "+";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button23.Location = new System.Drawing.Point(930, 460);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(56, 23);
            this.button23.TabIndex = 26;
            this.button23.Text = "-";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // ListNamed
            // 
            this.ListNamed.Location = new System.Drawing.Point(868, 489);
            this.ListNamed.Name = "ListNamed";
            this.ListNamed.Size = new System.Drawing.Size(118, 20);
            this.ListNamed.TabIndex = 25;
            this.ListNamed.Text = "Player Name";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(28, 519);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(817, 20);
            this.textBox2.TabIndex = 28;
            this.textBox2.Text = "Aeklys Soft by Fayz, Version 1.5 Beta Content";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button28
            // 
            this.button28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button28.Location = new System.Drawing.Point(868, 8);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(121, 23);
            this.button28.TabIndex = 53;
            this.button28.Text = "Edit Database ";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // TelecasterBox
            // 
            this.TelecasterBox.Location = new System.Drawing.Point(121, 56);
            this.TelecasterBox.Name = "TelecasterBox";
            this.TelecasterBox.Size = new System.Drawing.Size(100, 20);
            this.TelecasterBox.TabIndex = 54;
            this.TelecasterBox.Text = "Telecaster";
            this.TelecasterBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button33
            // 
            this.button33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button33.Location = new System.Drawing.Point(6, 445);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(811, 23);
            this.button33.TabIndex = 53;
            this.button33.Text = "Refresh";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1016, 542);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button22);
            this.Controls.Add(Buffs);
            this.Controls.Add(this.ListNamed);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.listView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            Buffs.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.firstlogin.ResumeLayout(false);
            this.firstlogin.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.Buff.ResumeLayout(false);
            this.Buff.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.Creature.ResumeLayout(false);
            this.Creature.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox SlotCreature;
        private System.Windows.Forms.TextBox Hunta;
        private System.Windows.Forms.TextBox GOLD;
        private System.Windows.Forms.TextBox PlayerValue;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox CreatureValue;
        private System.Windows.Forms.ComboBox CreatureListValue;
        private System.Windows.Forms.ComboBox PlayerValueList;
        private System.Windows.Forms.ComboBox JobBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button SetFlagBt;
        private System.Windows.Forms.TextBox FlagValue;
        private System.Windows.Forms.TextBox FlagName;
        private System.Windows.Forms.Button flagdelete;
        private System.Windows.Forms.TextBox deleteflag;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TextBox kickplayer;
        private System.Windows.Forms.Button GuildCDButton;
        private System.Windows.Forms.TextBox GuildCD;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.TextBox ListNamed;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage Buff;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button GiveItem;
        private System.Windows.Forms.TextBox ItemLevel;
        private System.Windows.Forms.TextBox ItemEnchant;
        private System.Windows.Forms.TextBox ItemAmmount;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox Iditem;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TextBox searchengine;
        private System.Windows.Forms.TextBox Nameitem5;
        private System.Windows.Forms.TextBox BuffName;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.TextBox SearchM;
        private System.Windows.Forms.TextBox IDBUFF;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.TextBox BuffTime;
        private System.Windows.Forms.TextBox BuffLevel;
        private System.Windows.Forms.TextBox NameMonster;
        private System.Windows.Forms.Button SearchMonsters;
        private System.Windows.Forms.TextBox SearchMEngine;
        private System.Windows.Forms.TextBox IdMonster;
        private System.Windows.Forms.Button GiveMonster;
        private System.Windows.Forms.TextBox SkillName;
        private System.Windows.Forms.Button SkillSearch;
        private System.Windows.Forms.TextBox SkillSearchEngine;
        private System.Windows.Forms.TextBox SkillID;
        private System.Windows.Forms.Button SkillGive;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox nbMonster;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Panel firstlogin;
        private System.Windows.Forms.TextBox UserBox;
        private System.Windows.Forms.TextBox IpBox;
        private System.Windows.Forms.TextBox ArcadiaBox;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button logbutton;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.TextBox stringres;
        private System.Windows.Forms.TabPage Creature;
        private System.Windows.Forms.TextBox AddPet;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.TextBox searchvaluepet;
        private System.Windows.Forms.Button searchpet;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button stade;
        private System.Windows.Forms.TextBox PetStade;
        private System.Windows.Forms.TextBox PetStadeSlot;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn x;
        private System.Windows.Forms.DataGridViewTextBoxColumn y;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.TextBox yMap;
        private System.Windows.Forms.TextBox xMap;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.TextBox TelecasterBox;
        private System.Windows.Forms.Button button33;
    }
}

